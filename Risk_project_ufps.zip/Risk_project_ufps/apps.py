from django.apps import AppConfig


class RiskProjectUfpsConfig(AppConfig):
    name = 'Risk_project_ufps'
